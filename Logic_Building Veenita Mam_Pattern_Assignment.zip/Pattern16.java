import java.util.Scanner;
class Pattern16
{
	public static void main(String[] args)
	{
		System.out.println("Enter the number of rows");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		for(int i=1;i<=n;i++)//i=1 i=2 i=3
		{
			for(int j=i;j<=n;j++)
			{
			    System.out.print("  ");
			}
			for(int j=1;j<=i;j++)/i=2;j=1;j=1	j=1-i=3		    *
															 //* 
															//*
														   //*
			{
				if(j==1||j==i)
				{
					System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
		System.out.println();
		}
	}
}
import java.util.Scanner;
class Pattern20{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the no of rows");
		int n=sc.nextInt();
		if(n%2==0)
		{
			n=n+1;
		}
		for(int i=0;i<n/2+1;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print("  ");
			}
			
			for(int j=i;j<=n-(i+1);j++)
			{
				if(j==i||j==n-(i+1)||i==0)
				{
				System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
			}
			
			System.out.println();
		}
		
		
	}
}
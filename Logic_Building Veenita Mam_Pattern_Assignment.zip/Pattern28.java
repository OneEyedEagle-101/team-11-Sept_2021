import java.util.Scanner;
class Pattern28
{
	public static void main(String[] args)
	{
		System.out.println("Enter the number of rows");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			for(int j=i;j<=n;j++)
			{	
			if(j==n)
				{
				System.out.print("* ");
				}
			else
			{
				System.out.print("  ");
			}
			}
			for(int j=2;j<2*i-1;j++)
			{
				System.out.print("  ");
			}
			for(int j=i;j<=n;j++)
			{
				if(i!=1)
				{
				 if(j==i)
				 {
					System.out.print("* ");
				 }
				}
			}
			System.out.println();
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=0;j<=i;j++)
			{
				if(i<n)
				{
				if(j==i)
				{
				System.out.print("* ");
				}
				else
				{
					System.out.print("  ");
				}
				}
			}
			for(int j=i;j<n-1;j++)
			{
				System.out.print("  ");
			}
			for(int j=i+1;j<n-1;j++)
			{
				System.out.print("  ");
			}
			for(int j=1;j<i;j++)
			{
				
				
				 if(j==1&&i<n)
				 {
				
				  System.out.print("* ");
				 }
				
			}
			System.out.println();
		}
	}
}
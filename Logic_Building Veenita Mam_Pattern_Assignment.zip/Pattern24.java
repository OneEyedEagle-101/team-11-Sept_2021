import java.util.Scanner;
class Pattern24
{
public static void main(String[] args)
{
	System.out.println("Enter the number of columns");
	Scanner sc= new Scanner(System.in);
	int n=sc.nextInt();
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<n;j++)
		{
			System.out.print("  ");
		}
		for(int j=1;j<=n;j++)
		{
			if(j==1||j==n||i==1||i==n)
			{
			System.out.print("* ");
			}
			else
			{
				System.out.print("  ");
			}
			
		}
		System.out.println();
	}
}
}
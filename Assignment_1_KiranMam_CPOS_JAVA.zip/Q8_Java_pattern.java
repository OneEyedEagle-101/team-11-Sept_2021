class Q8_Java_pattern
{
	public static void main(String args[])
	{
		for(int i=1;i<=4;i++)
		{
			for(int j=1;j<=30;j++)
			{
				
				if(i==1)
				{   
					if(j==4)
					{
					System.out.print("J ");
					}
					else if(j==8)
					{
						System.out.print("A ");
					}
					
					else if(j==12||j==18)
					{
						System.out.print("V ");
					}
					else if(j==22)
					{
						System.out.print("A ");
					}
					else
					{
						System.out.print("  ");
					}
				}
			}		
			for(int j=1;j<=30;j++)
			{
				
				if(i==2)
				{   
					if(j==4)
					{
					System.out.print("J ");
					}
					else if(j==7||j==9||j==21||j==23)
					{
						System.out.print("A ");
					}
					else if(j==13||j==17)
					{
						System.out.print("V ");
					}
					else
					{
						System.out.print("  ");
					}
				}
                				
			}
			for(int j=1;j<=30;j++)
			{
				
				if(i==3)
				{   
					if(j==4||j==1)
					{
					System.out.print("J ");
					}
					else if((j>5&&j<11)||(j>19&&j<25))
					{
						System.out.print("A ");
					}
					else if(j==14||j==16)
					{
						System.out.print("V ");
					}
					else
					{
						System.out.print("  ");
					}
				}
            }
			for(int j=1;j<=30;j++)
			{
				if(i==4)
				{
					if(j==2||j==3)
					{
						System.out.print("J ");
					}
				
					else if(j==5||j==11||j==19||j==25)
					{
					System.out.print("A ");
					}
					else if(j==15)
					{
					System.out.print("V ");
					}
					else{
					System.out.print("  ");
					}
				}
				
			}
			System.out.println();
			

			
		}
	}
}
import java.util.Scanner;

class Q4_Arithematic_operations
{
	public static void main(String args[])
	{
		System.out.println("Enter the Expression you want to Execute");
		System.out.println("Press a to execute x + y * z");
		System.out.println("Press b to execute (x+y) % z");
		System.out.println("Press c to execute w + -x*y /z ");
		System.out.println("Press d to execute u + v / w * x - y % z");
		System.out.println("Press e to exit");
		Scanner sc= new Scanner(System.in);
		
		char option;
		do
		{
			option = sc.next().charAt(0);
		switch(option)
		{
			
			case 'a':
			{
				System.out.println("The selected expression is x + y * z");
				System.out.print("Enter the value of x- ");
				int x= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of y- ");
				int y= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of z- ");
				int z= sc.nextInt();
				System.out.println();
				int res= x+(y*z);
				System.out.println("The result of expression x + y * z is - " + res);
				break;
				
			}
			case 'b':
			{
				System.out.println("The selected expression is (x+y) % z");
				System.out.print("Enter the value of x- ");
				int x= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of y- ");
				int y= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of z- ");
				int z= sc.nextInt();
				System.out.println();
				int res = x+ y % z;
				System.out.println("The result of expression (x+y) % z is - " + res );
				break;
				
			}
			case 'c':
			{
				System.out.println("The selected expression is w + -x*y /z ");
				System.out.print("Enter the value of w- ");
				int w= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of x- ");
				int x= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of y- ");
				int y= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of z- ");
				int z= sc.nextInt();
				System.out.println();
				int res= w + -((x*y )/z);
				System.out.println("The result of expression w + -x*y /z  is - " +  res );
				break;
				
			}
			case 'd':
			{
				System.out.println("The selected expression is u + v / w * x - y % z");
				System.out.print("Enter the value of u- ");
				int u= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of v- ");
				int v= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of w- ");
				int w= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of x- ");
				int x= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of y- ");
				int y= sc.nextInt();
				System.out.println();
				System.out.print("Enter the value of z- ");
				int z= sc.nextInt();
				System.out.println();
				System.out.println("The result of expression u + v / w * x - y % z is - " + (u + v / w * x-y % z));
				break;
			}
		}
		}while(option!='e');
		
	}
}
import java.util.Scanner;
class Q7_Multiplication_table
{
	public static void main(String args[])
	{
		System.out.print("Enter the number- ");
		Scanner sc= new Scanner(System.in);
		int num1=sc.nextInt();
		System.out.println();
		for(int i=1;i<=10;i++)
		{
			System.out.println(num1+" * "+i+" = "+num1*i);
		}
	}
}
		
import java.util.Scanner;
class Q13_Area_of_rectangle
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the Width - ");
		float length=sc.nextFloat();
		System.out.print("Enter the Height- ");
		float bredth=sc.nextFloat();
		System.out.println();
		
		System.out.println("The Area is "+ length+" * "+bredth+" = "+length*bredth);
		System.out.println("The Perimeter is 2 * ( "+ length+" + "+bredth+" ) = "+2*(length+bredth));
		
	}
}
import java.util.Scanner;

class Q3_Divide_two

{
	public static void main(String args[])
	{
		System.out.print("Enter the first number - ");
		Scanner sc= new Scanner(System.in);
		int num_1 = sc.nextInt();
		System.out.print("Enter the first number - ");
		int num_2 = sc.nextInt();
		System.out.println("The division of "+num_1+" and "+num_2 +" is = "+(num_1/num_2));
	}
}
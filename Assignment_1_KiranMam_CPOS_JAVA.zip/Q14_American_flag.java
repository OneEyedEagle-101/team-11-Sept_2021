public class Q14_American_flag
{
public static void main(String[] args)
{
int i,j,k;
for(i=1;i<=10;i++)
{
for(j=1;j<10;j++)
{
	if((i%2==0 && j%2==0)||i%2!=0 && j%2!=0)
	{
System.out.print("* ");
	}else
	{System.out.print("  ");
	}
}
for(k=1;k<=34;k++)
{
	System.out.print("= ");
}

System.out.println();
}
for(i=1;i<=15;i++)
{
	for(j=1;j<=43;j++)
	{
		System.out.print("= ");
	}
	System.out.println();
}
}
}


import java.util.Scanner;

class Q1_Print_Data

{
	public static void main(String args[])
	{
		System.out.println("Enter the data to be displayed - ");
		Scanner sc= new Scanner(System.in);
		String data= sc.nextLine();
		System.out.println(data);
	
	}
}
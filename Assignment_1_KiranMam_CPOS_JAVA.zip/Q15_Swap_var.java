import java.util.Scanner;
class Q15_Swap_var
{
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the value of A");
		int A=sc.nextInt();
		System.out.println("Enter the value of B");
		int B=sc.nextInt();
		System.out.println("The entered values are: A= "+A+"  B= "+B );
		System.out.println();
		A=A+B;
		B=A-B;
		A=A-B;
		System.out.println("The Swapped values are: A= "+A+"  B= "+B );
		
	}
}
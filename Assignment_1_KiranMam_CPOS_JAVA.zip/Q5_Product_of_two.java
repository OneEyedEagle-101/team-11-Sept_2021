import java.util.Scanner;
class Q5_Product_of_two
{
	public static void main(String args[])
	{
		System.out.println("Enter the first number - ");
		Scanner sc= new Scanner(System.in);
		int num1=sc.nextInt();
		System.out.println("Enter the Second number - ");
		int num2=sc.nextInt();
		System.out.println("The product of "+num1+" and "+num2+" is - "+num1*num2 );
	}
}
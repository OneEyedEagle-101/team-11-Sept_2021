import java.util.Scanner;
class Q12_Average
{
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the First number- ");
		int num1=sc.nextInt();
		System.out.println();
		System.out.print("Enter the Second number- ");
		int num2=sc.nextInt();
		System.out.println();
		System.out.print("Enter the Third number- ");
		int num3=sc.nextInt();
		System.out.println("The Average of"+num1+" & "+num2+" & "+num3+" is-  "+(num1+num2+num3)/3 );
		
	}
}
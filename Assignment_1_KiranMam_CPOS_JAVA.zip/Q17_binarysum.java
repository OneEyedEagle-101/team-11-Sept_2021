import java.util.Scanner;
class Q17_binarysum
{
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the 1st number");
		String a =sc.next();
		System.out.println("Enter the 2nd number");
		String b=sc.next();
		int m = Integer.parseInt(a,2);
		int n =Integer.parseInt(b,2);
		
		int c =m+n;
		String s = Integer.toBinaryString(c);
		System.out.println(s);
	}
}
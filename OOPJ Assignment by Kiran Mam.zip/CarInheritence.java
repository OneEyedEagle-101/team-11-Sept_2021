import java.util.Scanner;
abstract class Car
{
	boolean isSedan;
	String seats;
	Car(boolean isSedan,String seats)
	{
		this.isSedan=isSedan;
		this.seats=seats;
	}
	boolean isSedan()
	{
		return isSedan;
	}
	String getSeats()
	{
		return seats;
	}
	abstract String getMilage();
}
class WagonR extends Car
{
	int milage;
	String getMilage()
	{
		String s = String.valueOf(milage);
		return s;
	}
	WagonR(int a)
	{
		super(false,"4");
		this.milage=a;
	}
	void display()
	{
		
		System.out.print("A "+this.getClass().getSimpleName());
		if(isSedan()==true)
		{
			System.out.print(" is Sedan, is "+getSeats()+"-Seater and has a milage of around "+getMilage()+" kmpl");
		}
		else
		{
			System.out.print(" is not Sedan, is "+getSeats()+"-Seater and has a milage of around "+getMilage()+" kmpl");
		}
	}
}
class HondaCity extends Car
{
	int milage;
	String getMilage()
	{
		String s = String.valueOf(milage);
		return s;
	}
	HondaCity(int a)
	{
		super(true,"4");
		this.milage=a;
	}
	void display()
	{
		
		System.out.print("A "+this.getClass().getSimpleName());
		if(isSedan()==true)
		{
			System.out.print(" is Sedan, is "+getSeats()+"-Seater and has a milage of around "+getMilage()+" kmpl");
		}
		else
		{
			System.out.print(" is not Sedan, is "+getSeats()+"-Seater and has a milage of around "+getMilage()+" kmpl");
		}
	}
}
class InnovaCrysta extends Car
{
	int milage;
	String getMilage()
	{
		String s = String.valueOf(milage);
		return s;
	}
	InnovaCrysta(int a)
	{
		super(true,"6");
		this.milage=a;
	}
	void display()
	{
		
		System.out.print("A "+this.getClass().getSimpleName());
		if(isSedan()==true)
		{
			System.out.print(" is Sedan, is "+getSeats()+"-Seater and has a milage of around "+getMilage()+" kmpl");
		}
		else
		{
			System.out.print(" is not Sedan, is "+getSeats()+"-Seater and has a milage of around "+getMilage()+" kmpl");
		}
	}
}
class CarInheritence
{
	public static void main(String...args)
	{
		System.out.println("Please select the car Press: 0-WagonR 1-HondaCity 2-InnovaCrysta" );
		Scanner sc =new Scanner(System.in);
		int choice  = sc.nextInt();
		switch(choice)
		{
			case 0:
			{
				System.out.println("Enter the milage: ");
				int mil = sc.nextInt();
				if(mil>=5&&mil<=30)
				{
				WagonR car1 = new WagonR(mil);
				car1.display();
				}
				else
					System.out.println("Milage out of range");
				break;
			}
			case 1:
			{
				System.out.println("Enter the milage: ");
				int mil = sc.nextInt();
				if(mil>=5&&mil<=30)
				{
				HondaCity car2 = new HondaCity(mil);
				car2.display();
				}
				else
					System.out.println("Milage out of range");
				break;
			}
			case 2:
			{
				System.out.println("Enter the milage: ");
				int mil = sc.nextInt();
				if(mil>=5&&mil<=30)
				{
				InnovaCrysta car3 = new InnovaCrysta(mil);
				car3.display();
				}
				else
					System.out.println("Milage out of range");
				break;
			}
			default:
			{
				System.out.println("Invalid Choice");
			}
			
		}
	}
}










class Triangle
{
	void method()
	{
		System.out.println("I am a Triangle");
	}
}
class Isosceles extends Triangle
{
	void method()
	{
	System.out.println("I am an Isosceles Triangle");
	super.method();
	}
}
class Equilateral extends Isosceles
{
	void method()
	{
	System.out.println("I am an Equilateral Triangle");	
	super.method();
	}
}

class TriangleMain
{
	public static void main(String...args)
	{
		Triangle s1=new Equilateral();
		s1.method();
	}
}
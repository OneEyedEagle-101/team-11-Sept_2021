import java.util.Scanner;
class Character_check{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the alphabet");
		char alphabet=sc.next().charAt(0);
		int a = (int)alphabet;
		if(a>=65&&a<=90)
		{
			System.out.println("The Entered character is a UPPERCASE");
		}
		else if(a>=97&&a<=122)
		{
			System.out.println("The Entered character is a lowercase");
		}
		else{
			System.out.println("It is not a alphabet");
		}
	}
}
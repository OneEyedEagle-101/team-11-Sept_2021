import java.util.Scanner;
public class Compare{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the value of A= ");
		
		int a= sc.nextInt();
		System.out.print("Enter the value of B= ");
		int b= sc.nextInt();
		if(a>b)
		{
			System.out.println("A is greater than B");
		}
		else if(a<b)
		{
			System.out.println("B is greater than A");
		}
		else
			System.out.println("The value of A and B is same");
	}
}
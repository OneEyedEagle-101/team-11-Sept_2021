import java.util.Scanner;
public class Swap{
	public static void main(String[] agrs)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the two numbers you want to swap");
		System.out.print("a= ");
		int a= sc.nextInt();
		System.out.print("b= ");
		int b= sc.nextInt();
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("The swapped value of a and b is");
		System.out.print("a="+a+"  b="+b );
	}
}
import java.util.Scanner;
class Unit_conversion
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the length in centimeters");
		float cm= sc.nextInt( );
		double km = cm/100;
		System.out.println("The length in kilometer is  "+ km);
		
	}	
}
import java.util.Scanner;
class Discount{
	public static void main(String[] args)
	{
		System.out.print("Enter the Purchase Amount in Rs.");
		Scanner sc =new Scanner(System.in);
		int Amt = sc.nextInt();
		if(Amt>=1000)
		{
			System.out.println("You are eligible for the discount of 10%");
			int dis=Amt-Amt/10;
			System.out.print("The Discounted amount is "+dis);
		}
		else 
		{
			System.out.println("You are not eligible for the purchase please buy more things costing upto "+(1000-Amt)+".Rs");
		}
	}
}
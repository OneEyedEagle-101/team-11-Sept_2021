import java.util.Scanner;
class Average{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the 1st number");
		int num1= sc.nextInt();
		System.out.println("Enter the 2nd number");
		int num2= sc.nextInt();
		System.out.println("Enter the 3rd number");
		int num3=sc.nextInt();
		System.out.println("The average of the above three numbers is  "+ (num1+num2+num3)/3);
	}
}
import java.util.Scanner;
class Grade{
	public static void main(String[] args)
	{
		System.out.println("Enter the Obtained marks-");
		Scanner sc= new Scanner(System.in);
		int mrk= sc.nextInt();
		if(mrk>=0&&mrk<=25)
		{
			System.out.println("You have obtained grade F");
		}
		else if(mrk>25&&mrk<=45)
		{
			System.out.println("You have obtained grade E");
		}
		else if(mrk>45&&mrk<=50)
		{
			System.out.println("You have obtained grade D");
		}
		else if(mrk>50&&mrk<=60)
		{
			System.out.println("You have obtained grade C");
		}
		else if(mrk>60&&mrk<=80)
		{
			System.out.println("You have obtained grade B");
		}
		else if(mrk>80)
		{
			System.out.println("You have obtained grade A");
		}
		else{
			System.out.println("The Entered value is out of range");
		}
	}
}
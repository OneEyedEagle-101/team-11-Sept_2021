import java.util.Scanner;
public class Odd_numbers{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the number from which you want odd values = ");
		
		int a= sc.nextInt();
		System.out.print("Enter the number upto which you want odd values= ");
		int b= sc.nextInt();
		int i;
		System.out.println("The list of odd numbers from "+a+" to " +b+" is");
		for(i=a; i<=b;i++)
		{
			if(i%2!=0)
			{
				System.out.println(i);
			}
		}
	}
}
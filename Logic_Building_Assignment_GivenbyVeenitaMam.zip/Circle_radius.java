import java.util.Scanner;
class Circle_radius{
	public static void main(String[] args)
	{
		System.out.println("Enter the radius of the circle");
		Scanner sc= new Scanner(System.in);
		int rad= sc.nextInt();
		System.out.println("The diameter of the circle is "+2*rad);
		System.out.println("The circumference of the circle is "+ 2*3.14*rad);
		System.out.println("The area of the circle is "+ 3.14*rad*rad);
	}
}
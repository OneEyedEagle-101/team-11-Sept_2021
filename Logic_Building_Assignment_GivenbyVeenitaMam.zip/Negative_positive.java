import java.util.Scanner;
class Negative_positive{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		int i;
		System.out.println("Enter the number : ");
		int num=sc.nextInt();
		if(num>0)
		{
			System.out.println("The number "+num+" is positive");
		}
		else if(num<0)
		{
			System.out.println("The number "+num+" is negative");
		}
		else
		{
			System.out.println("The number "+num+" is zero");
		}
	}
}
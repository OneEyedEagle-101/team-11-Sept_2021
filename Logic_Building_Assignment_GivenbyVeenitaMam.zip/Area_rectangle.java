import java.util.Scanner;

class Area_rectangle{
	public static void main(String[] args)
	{
		System.out.println("Enter the length");
		Scanner sc= new Scanner(System.in);
		int x=sc.nextInt();
		System.out.println("Enter the bredth");
		int y= sc.nextInt();
		int Area= x*y;
		System.out.println("The area of the rectangle is"+Area);
	}
}
import java.util.Scanner;
class Sum_of_Natural{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		int i;
		System.out.println("Enter the number ");
		int num=sc.nextInt();
		System.out.print("The list of natural number upto "+num+" is - ");
		for(i=1;i<=num;i++)
		{
			System.out.print( i+", ");
		}
		int sum=0;
		System.out.println("");
		
		for(i=0;i<=num;i++)
		{
			sum=sum+i;
			
		}
		System.out.print("The sum of natural number upto "+num+" is = "+sum);
		
	}
}
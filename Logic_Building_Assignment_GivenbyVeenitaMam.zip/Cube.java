
import java.util.Scanner;
class Cube{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		int i;
		System.out.println("Enter the number upto which you want to find cube");
		int num=sc.nextInt();
		System.out.print("The list of cubes upto "+num+" is: ");
		int cube =0;
		for(i=1;i<=num;i++)
		{
			cube=i*i*i;
			System.out.print(cube+", ");
		}
	}
}
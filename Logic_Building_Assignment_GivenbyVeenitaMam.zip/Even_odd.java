import java.util.Scanner;
public class Even_odd{
	public static void main(String[] args){
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number you want to check is even or odd");
		int a=sc.nextInt();
		if(a%2==0)
		{
			System.out.println("The number "+a+" is a even number");
		}
		else
		{
			System.out.println("The number "+a+" is a odd number");
		}
	}
}
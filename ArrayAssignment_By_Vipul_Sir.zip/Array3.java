/*3. Write a program which generates the series 1,4,27,16,125,36*/
import java.util.Scanner;
class Series
{
	static void ser(int n)
	{
		if(n==1)
		{	System.out.print(n+", ");
			return;
		}
		if(n%2==0)
		{
			ser(n-1);
			System.out.print(n*n+", ");
		}
		if(n%2!=0)
		{
		ser(n-1);
		System.out.print(n*n*n+", ");
		}
		
	}
	public static void main(String...args)
	{
		Scanner sc = new Scanner(System.in);
		
		ser(6);
	}
}
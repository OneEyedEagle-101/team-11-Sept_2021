/*4.Given an array of integers, print whether the numbers are in ascending order or in descending order or 
in random order without sorting
 Input: [5,14,35,90,139] Output: Ascending 
 Input: [88,67,35,14,-12] Output: Descending
Input: [65,14,129,34,7] Output: Random */


import java.util.Scanner;
import java.io.*;


class Array4
{
	public static void main(String...args) throws Exception
	{
		System.out.println("Enter the no. of elements of an array");
		Scanner sc=new Scanner(System.in);
		int[] arr =new int[sc.nextInt()];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		int count=0;
		int countdesc=0;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
			if(arr[1]>arr[2])
			{	
				if(arr[i]>arr[j])
				{
					countdesc++;
					continue;
				}
				else
				{
					countdesc=0;
				}
			}
			if(arr[1]<arr[2])
			{
				if(arr[i]<arr[j])
				{
					count++;
				}
				else
				{
					count=0;
				}
			}
			}
		}
		if(countdesc>=arr.length*2)
		{
			System.out.println("Descending");
		}
		else if(count>=arr.length*2)
		{
			System.out.println("Ascending");
		}
		else
		{
			System.out.println("Random");
		}

		
	}
}
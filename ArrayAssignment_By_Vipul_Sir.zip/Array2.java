/*.Write a program which takes an array of integers and prints the running average of 3 consecutive integers. 
In case the array has fewer than 3 integers, there should be no output.
 Input: [5,14,35,89,140]
 Output: [18, 46, 88] 
(Explanation: 18=(5+14+35/3, 46=(14+35+89)/3, ...)
*/

import java.util.*;
class Array2
{
	public static void main(String...args)
	{
		System.out.println("Enter the size of Array");
		Scanner sc =new Scanner(System.in);
		
		int[] arr =new int[sc.nextInt()];
		if(arr.length>=3)
		{
			System.out.println("Enter the Array Elements for Running average");
			for(int i=0;i<arr.length;i++)
			{
				arr[i]=sc.nextInt();
			}
			 
			int[] arr2 =new int[arr.length-2];
			for(int i=0 ;i<arr2.length;i++)
			{
				int sum =0;
				sum = sum + (arr[i]+arr[i+1]+arr[i+2])/3;
				arr2[i]=sum;
			}
			System.out.println(Arrays.toString(arr2));
		}
		else
			System.out.println("Enter 3 or more than 3 elements");
	}
}
/*5.Print the third-largest number in an array without sorting it 
Input: [ 24,54,31,16,82,45,67]
Output: 54 (82 and 67 are the largest and second-largest)*/

import java.util.*;

class Array5
{
	public static void main(String...args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of array");
		int[] arr=new int[sc.nextInt()];
		int grt1;
		int grt2;
		System.out.println("Enter the elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		int val=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>val)
			{
				val=arr[i];
			}
		}
		grt1=val;
		val=0;
		for(int i=0;i<arr.length;i++)
		{
			
			if(grt1==arr[i])
			{
				continue;
			}
			else if(arr[i]>val)
			{
				val=arr[i];
			}
		}
		grt2=val;
		val=0;
		for(int i=0;i<arr.length;i++)
		{
			if(grt1==arr[i]||grt2==arr[i])
			{
				continue;
			}
			else if(arr[i]>val)
			{
				val=arr[i];
			}
		}
		System.out.println("The third Greatest number is "+val);
	}
}	
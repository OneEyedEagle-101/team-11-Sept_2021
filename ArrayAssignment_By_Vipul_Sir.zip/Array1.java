/*1. Write a program to merge two arrays of integers by reading one number at a time from each array until 
one of the array is exhausted, and then concatenating the remaining numbers.
 Input: [23,60,94,3,102] and [42,16,74]
 Output: [23,42,60,16,94,74,3,102]*/
 
 
 import java.util.*;
 class Array1
 {
	 public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the Size of First array");
		 int size =sc.nextInt();
		 int[] arr1 =new int[size];
		 System.out.println("Enter the Elements of array1");
		 for(int i=0;i<arr1.length;i++)
		 {
			 arr1[i]=sc.nextInt();
		 }
		 System.out.println("Enter the Size of Second array");
		 size =sc.nextInt();
		 int[] arr2 =new int[size];
		 System.out.println("Enter the Elements of array2");
		 for(int i=0;i<arr2.length;i++)
		 {
			 arr2[i]=sc.nextInt();
		 }
		 int[] arr3 =new int[arr1.length+arr2.length];
		 
		 
		 if(arr1.length>arr2.length)
		 {
			 int i=0;
		    for(int j=0,m=0; j<arr2.length ;m=m+2,j++)
			{
			arr3[m]=arr1[j];
			}
			
		 for(i=2*arr2.length ;i<arr3.length;i++ )
		 {
			 arr3[i]=arr1[i-arr2.length];
		 }
		 for(int j=1,m=0; m<arr2.length ;m++,j=j+2)
		 {
			 arr3[j]=arr2[m];
		 }
		 }
		 else if(arr2.length>arr1.length)
		 {
			for(int i=0,j=0;i<arr1.length+2;j++,i=i+2)
			{
				arr3[i]=arr1[j];
				
			}
			for(int i=2*arr1.length-1;i<arr3.length;i++)
			{
				arr3[i]=arr2[i-arr1.length];
			}
			for(int i=1,j=0 ;i<arr1.length+1;i=i+2,j++)
			{
				arr3[i] = arr2[j];
			}	
		 }
			 
		System.out.println(Arrays.toString(arr3));
	 }
 }
/*

This question is asked by Facebook. Given a string, return whether or not it forms a palindrome ignoring case and non-alphabetical characters.
Note: a palindrome is a sequence of characters that reads the same forwards and backwards.

Ex: Given the following strings...

"A man, a plan, a canal: Panama.", return true

*/


import java.util.*;

class Palindrome
{
	public static void main(String...args)
	{
		Scanner sc= new Scanner (System.in);
		String line=sc.nextLine();
		String s2 = line.replaceAll("[^A-Za-z]","");
		String newline =s2.toLowerCase();
		int len = newline.length();
		char[] arr=new char[len];
		char[] arr2=new char[len];
		arr=newline.toCharArray();
		int i=0;
		int j=arr.length-1;
		
		while(i<arr.length && j>=0 )
		{
			arr2[i]=arr[j];
			i++;
			j--;
		}
		int counter=0;
		i=0;

		while(i<arr.length)
		{
			if(arr[i]==arr2[i])
			{
				counter++;
			}
			else{counter=0;}
			i++;
		}
		if(counter==len)
		{
			System.out.println("is Palindrome");
		}
		else
		{
			System.out.println("not palindrome");
		}
		
	}
}
/*TEST CASES  [1, 3, 8, 2], k = 10, return true (8 + 2)
[3, 9, 13, 7], k = 8, return false
[4, 2, 6, 5, 2], k = 4, return true (2 + 2)
*/
import java.util.Scanner;
class Sum_check
{
	public static void main(String[] args)
	{
	System.out.println("Enter the length of array - ");
	Scanner sc=new Scanner(System.in);
	int arr_len=sc.nextInt();
	int arr[]=new int[arr_len];
	for(int i=0; i<arr_len;i++)
	{	
		System.out.print("Enter the"+i+" Element-");
		arr[i]=sc.nextInt();	
	}
	System.out.println();
	System.out.println("Enter the Sum you want to check - ");
	int k=sc.nextInt();
	int counter=0;
	for(int i=0;i<arr.length;i++)
	{
		int m = arr[i];
		for(int j=0;j<arr.length;j++)
		{
			int n=arr[j];
			if(i!=j)
			{
				if(arr[i]+arr[j]==k)
				{
					counter++;
				}
			}
		}
	}
	if(counter>0)
	{
		System.out.println("True");
	}
	else
	{
		System.out.println("False");
	}
	}
}
